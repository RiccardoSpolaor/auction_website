/*import mongoose = require('mongoose');

import express = require('express');
import bodyparser = require('body-parser');

import {User} from "./User";
import * as user from "./User";

export function getUserId(usermail : string){
    if (usermail)
        user.getModel().find( {mail: usermail} ).then((documents) => {return documents})
    .catch( (reason) => {
    return next({ statusCode:404, error: true, errormessage: "DB error: "+reason });
  })*/